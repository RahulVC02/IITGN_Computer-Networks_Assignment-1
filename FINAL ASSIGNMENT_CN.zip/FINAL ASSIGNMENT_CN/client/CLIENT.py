import socket
import utilities
import sys

HOST = '192.168.56.1'
PORT = utilities.PORT

if __name__ == '__main__':

    while True:
        try:
            # sets up the TCP socket from client side
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect((HOST, PORT))

            print('\nConnected to {}:{}'.format(HOST, PORT))

            # user chooses the encryption mode and this is communicated to the server
            data = input("Choose your encryption mode - 0, 1 or 2: ")
            utilities.send_msg(sock, data)

            if(data == "0"):
                print("Type your command, press enter to send, 'exit' to quit")
                msg = input()
                tokens = msg.split()

                # exits the session on reading this command and socket closes
                if msg == 'exit':
                    print("Connection closed!")
                    break

                # download command followed by the filename
                elif tokens[0] == "dwd":

                    utilities.send_msg(sock, msg)

                    # string manipulation for the multi-word filename
                    filename = tokens[1]
                    for i in range(2, len(tokens)):
                        filename = filename + " " + tokens[i]

                    # writes into file with same name with a packet size of 1024
                    with open(filename, 'w') as f:
                        while(1):
                            data = sock.recv(1024).decode()
                            if not data:
                                break
                            f.write(data)
                            if len(data) < 1024:
                                break
                        f.close()

                    # receives confirmation message from the server that the download
                    # is completed
                    msg = utilities.recv_msg(sock)
                    print(msg)

                # the upload command followed by a filename
                elif tokens[0] == "upd":

                    utilities.send_msg(sock, msg)

                    # read the filename if it is multi-word
                    filename = tokens[1]
                    for i in range(2, len(tokens)):
                        filename = filename + " " + tokens[i]

                    # client reads from the file to be uploaded and sends the
                    # bytes in packets of size 1024

                    with open(filename, 'r') as f:
                        while(1):
                            data = f.read(1024)
                            if not data:
                                break
                            data = data.encode('utf-8')
                            sock.sendall(data)
                        f.close()

                    # client send the confirmation message to the server that
                    # the entire file has been uploaded

                    msg = utilities.recv_msg(sock)
                    print(msg)

                # these are the remaining three commands
                # command word is sent to server and
                # the response generation is done on server side
                else:
                    utilities.send_msg(sock, msg)
                    print('Sent message: {}'.format(msg))
                    msg = utilities.recv_msg(sock)
                    print('Received echo: ' + msg)

            # This is the substitute mode of encryption
            elif (data == "1"):
                print("Type your command, press enter to send, 'exit' to quit")
                msg = input()
                tokens = msg.split()

                # exits the session on reading this command and socket closes
                if msg == 'exit':
                    print("Connection closed!")
                    break

                # download command followed by the filename
                elif tokens[0] == "dwd":
                    utilities.send_msg(sock, utilities.encrypt_sub(msg))

                    # reading the filename from command

                    filename = tokens[1]
                    for i in range(2, len(tokens)):
                        filename = filename + " " + tokens[i]

                    # opening a file with same name and decrypting the data sent
                    # by server and writing it into the file.

                    with open(filename, 'w') as f:
                        while(1):
                            data = sock.recv(1024).decode()
                            data = utilities.decrypt_sub(data)
                            if not data:
                                break
                            f.write(data)
                            if len(data) < 1024:
                                break
                        f.close()

                    # client receives confirmation message from the server that
                    #download is completed

                    msg = utilities.recv_msg(sock)
                    msg = utilities.decrypt_sub(msg)
                    print(msg)

                # the upload command followed by a filename
                elif tokens[0] == "upd":

                    utilities.send_msg(sock, utilities.encrypt_sub(msg))

                    # reading the filename
                    filename = tokens[1]
                    for i in range(2, len(tokens)):
                        filename = filename + " " + tokens[i]

                    # reading the characters and sending them in encrypted mode in packets of size 1024
                    with open(filename, 'r') as f:
                        while(1):
                            data = f.read(1024)
                            if not data:
                                break
                            data = utilities.encrypt_sub(data)
                            data = data.encode('utf-8')
                            sock.sendall(data)
                        f.close()

                    # receiving the confirmation message from the server that the
                    #upload is completed

                    msg = utilities.recv_msg(sock)
                    msg = utilities.decrypt_sub(msg)
                    print(msg)

                # these are the remaining three commands
                # command word is sent to server and
                # the response generation is done on server side
                else:

                    utilities.send_msg(sock, utilities.encrypt_sub(msg))
                    print('Sent message: {}'.format(msg))
                    msg = utilities.recv_msg(sock)
                    msg = utilities.decrypt_sub(msg)
                    print('Received echo: ' + msg)

            elif (data == "2"):
                print("Type your command, press enter to send, 'exit' to quit")
                msg = input()
                tokens = msg.split()

                # exits the session on reading this command and socket closes
                if msg == 'exit':
                    print("Connection closed!")
                    break

                # download command followed by the filename
                elif tokens[0] == "dwd":

                    utilities.send_msg(sock, utilities.transpose(msg))

                    # reading the filename
                    filename = tokens[1]
                    for i in range(2, len(tokens)):
                        filename = filename + " " + tokens[i]

                    # decrypting the received data and writing it into
                    # the file with same name

                    with open(filename, 'w') as f:
                        while(1):
                            data = sock.recv(1024).decode()
                            data = utilities.transpose(data)

                            if not data:
                                f.close()
                                break
                            f.write(data)
                            if len(data) < 1024:
                                f.close()
                                break

                    # getting confirmation message from server
                    msg = utilities.recv_msg(sock)
                    msg = utilities.transpose(msg)
                    print(msg)

                # the upload command followed by a filename
                elif tokens[0] == "upd":

                    utilities.send_msg(sock, utilities.transpose(msg))

                    # reading the filename
                    filename = tokens[1]
                    for i in range(2, len(tokens)):
                        filename = filename + " " + tokens[i]

                    # reading the characters and sending them in encrypted mode in packets of size 1024
                    with open(filename, 'r') as f:
                        while(1):
                            data = f.read(1024)
                            if not data:
                                f.close()
                                break
                            data = utilities.transpose(data)
                            data = data.encode('utf-8')
                            sock.sendall(data)

                    # getting the confirmation message from the server
                    msg = utilities.recv_msg(sock)
                    msg = utilities.transpose(msg)
                    print(msg)
                else:
                    utilities.send_msg(sock, utilities.transpose(msg))
                    print('Sent message: {}'.format(msg))
                    msg = utilities.recv_msg(sock)
                    msg = utilities.transpose(msg)
                    print('Received echo: ' + msg)
            else:
                print("Please select a valid encryption mode!")
        except ConnectionError:
            print('Socket Error Occured')
            sock.close()
            break
        finally:
            sock.close()
            print('Closed connection to server\n')
