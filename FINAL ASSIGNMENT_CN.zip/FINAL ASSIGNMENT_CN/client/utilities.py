import socket
import os

HOST = '192.168.56.1'  # can be set to user's IP address/ tester's IP address
PORT = 4040

##############################################################################

# The following four methods were taken from the Learn Network Programming in Python
# book. These functions help provide functions which are commonly used.


def create_listen_socket(host, port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind((host, port))
    sock.listen(100)
    return sock


def recv_msg(sock):
    data = bytearray()
    msg = ''
    while not msg:
        recvd = sock.recv(4096)
        if not recvd:
            raise ConnectionError()
        data = data + recvd
        if b'\0' in recvd:
            msg = data.rstrip(b'\0')
            break

    msg = msg.decode('utf-8')

    return msg


def prep_msg(msg):
    msg += '\0'
    return msg.encode('utf-8')


def send_msg(sock, msg):

    data = prep_msg(msg)
    sock.sendall(data)

#################################################################################

#################################################################################
# The following three functions use OS system call APIs and generate the response
# on the basis of user's query


def curr_dir():
    a = os.getcwd()
    return a


def ls(p):
    b = os.listdir(p)
    return b


def change_dir(p):
    os.chdir(p)
    return os.getcwd()

################################################################################

################################################################################

# This is the encryption method used for the Substitute mode. It uses a fixed offset
# equal to 2


def encrypt_sub(msg):
    encrypted = ""
    offset = 2

    for i in range(len(msg)):
        char = msg[i]
        if(char.isalnum()):
            if(char.isupper()):  # for uppercase letters
                encrypted += chr((ord(char)-65+offset) % 26 + 65)
            elif(char.islower()):  # for lowecase letters
                encrypted += chr((ord(char)-97+offset) % 26 + 97)
            else:  # for numbers
                encrypted += chr((ord(char)-48+offset) % 10 + 48)
        else:
            encrypted += char

    return encrypted

# This is the decryption routine for the Substitute mode. It uses an offset value
# of 2 and subtracts it to decrypt the characters.


def decrypt_sub(msg):
    decrypted = ""
    offset = 2
    for i in range(len(msg)):
        char = msg[i]
        if(char.isalnum()):
            if(char.isupper()):  # for uppercase letters
                decrypted += chr((ord(char) - 65 - offset) % 26 + 65)
            elif(char.islower()):  # for lowercase letters
                decrypted += chr((ord(char) - 97 - offset) % 26 + 97)
            else:  # for numbers
                decrypted += chr((ord(char) - 48 - offset) % 10 + 48)
        else:
            decrypted += char

    return decrypted


# This is the encryption and decryption routine for the Transpose mode. Both
# encryption and decryption work in the same way.

def transpose(msg):
    reversed = ""
    words = msg.split()  # prepares a list of words in the text

    for i in range(len(words)):
        words[i] = words[i][::-1]  # reverses each word

    for i in range(len(words) - 1):
        reversed = reversed + words[i] + " "  # concatenates word in original
        # word order but words are reversed
    reversed += words[len(words) - 1]

    return reversed  # this is the reversed text

##############################################################################
