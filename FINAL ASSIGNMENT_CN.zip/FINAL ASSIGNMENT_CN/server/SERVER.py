import os
import utilities

HOST = utilities.HOST
PORT = utilities.PORT


def handle_client(sock, addr):
    try:

        #this is the encryption mode data sent by the client
        data = utilities.recv_msg(sock)


        #In plaintext mode
        if(data == "0"):

            msg = utilities.recv_msg(sock)
            print('{}: {}'.format(addr, msg))
            print("Received message: " + msg)
            tokens = msg.split()

            #uses the utility functions we made
            if msg.lower() == "cwd":
                output = utilities.curr_dir()
                utilities.send_msg(sock, output)

            if msg.lower() == "ls":
                path = utilities.curr_dir()
                output = str(utilities.ls(path))
                utilities.send_msg(sock, output)

            #navigates to the path of directory that user specifies
            #else returns that no such directory exists
            if msg.split(" ")[0].lower() == "cd":
                path = msg.split(" ")[1]
                for i in range(2, len(msg.split(" "))):
                    path += " " + msg.split(" ")[i]

                if path in os.listdir() or path == '..':
                    output = utilities.change_dir(path)
                    utilities.send_msg(sock, output)
                else:
                    output = "No such directory exists!"
                    utilities.send_msg(sock, output)

            if msg.split(" ")[0].lower() == "dwd":

                #finds out the filename
                filename = tokens[1]
                for i in range(2, len(tokens)):
                    filename += " " + tokens[i]
                
                #reads and sends the encrypted data via socket to client
                with open(filename, 'r') as f:
                    while(1):
                        data = f.read(1024)
                        if not data:
                            break
                        data = data.encode('utf-8')
                        sock.sendall(data)
                    f.close()
                
                #sends confirmation message to the user
                msg = "Download Completed!"
                utilities.send_msg(sock, msg)


            #the upload handling
            if msg.split(" ")[0].lower() == "upd":

                #finds out the filename
                filename = tokens[1]
                for i in range(2, len(tokens)):
                    filename += " " + tokens[i]
                
                #creates and writes into a file with same name by receiving
                #data packets from the client

                with open(filename, 'w') as f:
                    while(1):
                        data = sock.recv(1024).decode()
                        if not data:
                            f.close()
                            break
                        f.write(data)
                        if len(data) < 1024:
                            f.close()
                            break
                
                #sends the confirmation message to the user
                msg = "Upload Completed!"
                utilities.send_msg(sock, msg)


        #in the Substitute mode of encryption
        elif (data == "1"):

            msg = utilities.recv_msg(sock)
            msg = utilities.decrypt_sub(msg)
            print('{}: {}'.format(addr, msg))
            print("Received message: " + msg)
            tokens = msg.split()

            #handles these cases using the OS directives
            #send the response in encrypted form
            if msg.lower() == "cwd":
                output = utilities.curr_dir()
                utilities.send_msg(sock, utilities.encrypt_sub(output))

            if msg.lower() == "ls":
                path = utilities.curr_dir()
                output = str(utilities.ls(path))
                utilities.send_msg(sock, utilities.encrypt_sub(output))
            

            if msg.split(" ")[0].lower() == "cd":

                #find the file path name
                path = msg.split(" ")[1]
                for i in range(2, len(msg.split(" "))):
                    path += " " + msg.split(" ")[i]
                
                #returns the response file path in encrypted form

                if path in os.listdir() or path == '..':
                    output = utilities.change_dir(path)
                    utilities.send_msg(
                        sock, utilities.encrypt_sub(output))
                else:
                    output = "No such directory exists!"
                    utilities.send_msg(
                        sock, utilities.encrypt_sub(output))
            

            if msg.split(" ")[0].lower() == "dwd":

                #figures out the filename

                filename = tokens[1]
                for i in range(2, len(tokens)):
                    filename += " " + tokens[i]

                #reads and sends encrypted data to the client
                with open(filename, 'r') as f:
                    while(1):
                        data = f.read(1024)
                        if not data:
                            break
                        data = utilities.encrypt_sub(data)
                        data = data.encode('utf-8')
                        sock.sendall(data)
                    f.close()
                
                #sends the confirmation message to the client
                msg = "Download Completed!"
                utilities.send_msg(sock, utilities.encrypt_sub(msg))


            #navigates and finds the filename and writes into the file having same name
            #decrypts the uploaded data sent by the client.
            if msg.split(" ")[0].lower() == "upd":
                filename = tokens[1]
                for i in range(2, len(tokens)):
                    filename += " " + tokens[i]
                with open(filename, 'w') as f:
                    while(1):
                        data = sock.recv(1024).decode()
                        data = utilities.decrypt_sub(data)
                        if not data:
                            f.close()
                            break
                        f.write(data)
                        if len(data) < 1024:
                            f.close()
                            break
                
                #sends confirmation message to the client
                msg = "Upload Completed!"
                utilities.send_msg(sock, utilities.encrypt_sub(msg))


        #in the transpose mode of encryption
        elif (data == "2"):

            msg = utilities.recv_msg(sock)
            msg = utilities.transpose(msg)

            print('{}: {}'.format(addr, msg))
            print("Received message: " + msg)
            tokens = msg.split()

            #handles these cases using OS directives and sends encrypted data
            #as the response
            if msg.lower() == "cwd":
                output = utilities.curr_dir()
                utilities.send_msg(sock, utilities.transpose(output))

            if msg.lower() == "ls":
                path = utilities.curr_dir()
                output = str(utilities.ls(path))
                utilities.send_msg(sock, utilities.transpose(output))
            

            if msg.split(" ")[0].lower() == "cd":

                #find the file path
                path = msg.split(" ")[1]
                for i in range(2, len(msg.split(" "))):
                    path += " " + msg.split(" ")[i]

                #returns the file path if it exists in encrypted mode
                if path in os.listdir() or path == '..':
                    output = utilities.change_dir(path)
                    utilities.send_msg(
                        sock, utilities.transpose(output))
                else:
                    output = "No such directory exists!"
                    utilities.send_msg(
                        sock, utilities.transpose(output))

            #send the encrypted data from the specified file in packets
            #of size 1024 bytes
            if msg.split(" ")[0].lower() == "dwd":
                filename = tokens[1]
                for i in range(2, len(tokens)):
                    filename += " " + tokens[i]

                with open(filename, 'r') as f:
                    while(1):
                        data = f.read(1024)
                        if not data:
                            f.close()
                            break
                        data = utilities.transpose(data)
                        data = data.encode('utf-8')
                        sock.sendall(data)

                msg = "Download Completed!"
                utilities.send_msg(sock, utilities.transpose(msg))

            #reads the data from the client and decrypts it before writing
            #into the file
            if msg.split(" ")[0].lower() == "upd":
                filename = tokens[1]
                for i in range(2, len(tokens)):
                    filename += " " + tokens[i]
                with open(filename, 'w') as f:
                    while(1):
                        data = sock.recv(1024).decode()
                        data = utilities.transpose(data)
                        if not data:
                            f.close()
                            break
                        f.write(data)
                        if len(data) < 1024:
                            f.close()
                            break
                
                #send confirmation message to client
                msg = "Upload Completed!"
                utilities.send_msg(sock, utilities.transpose(msg))
        else:
            print("Invalid encryption mode!")
    except (ConnectionError, BrokenPipeError):
        print('Socket Error')

    finally:
        print('Closed connection to {}'.format(addr))
        sock.close()


if __name__ == '__main__':

    #making the server-side socket and making it listen for connections
    listen_sock = utilities.create_listen_socket(HOST, PORT)
    addr = listen_sock.getsockname()
    print('Listening on {}'.format(addr))

    #listening for connections from the client till the client commands exit
    #and closes socket
    #server is always on and listening
    while True:
        client_sock, addr = listen_sock.accept()
        print('Connection from {}'.format(addr))
        handle_client(client_sock, addr)
